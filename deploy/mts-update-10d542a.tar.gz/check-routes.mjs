import assert from "node:assert/strict";

const origin = new URL(process.argv[2]);
const registry = "/itsm/incidents";

async function get(path, mediaType) {
  const response = await fetch(new URL(path, origin), {
    redirect: "error",
    signal: AbortSignal.timeout(8000),
  });
  assert.equal(response.status, 200, path);
  const contentType = response.headers.get("content-type")?.split(";")[0];
  assert.ok(mediaType.test(contentType), path);
  return response;
}

const { items } = await (await get("/api/v1" + registry, /^application\/json$/i)).json();
const ticket = items?.find((item) => typeof item.id === "string" && item.id.length > 0);
assert.ok(ticket, "The ITSM registry must contain at least one ticket to verify a direct link");
const detail = registry + "/" + encodeURIComponent(ticket.id);
const record = await (await get("/api/v1" + detail, /^application\/json$/i)).json();
assert.equal(record.ticket?.id, ticket.id);

for (const path of ["/admin/incidents", "/admin/developers", registry, detail]) {
  const html = await (await get(path, /^text\/html$/i)).text();
  assert.match(html, /<title>Пульт координатора<\/title>/u);
  const script = html.match(/<script\b[^>]*\bsrc="(\/assets\/[^"]+\.js)"/u)?.[1];
  assert.ok(script, "Missing application script");
  await (await get(script, /^(?:text|application)\/javascript$/i)).body.cancel();
  console.log(path === detail ? "/itsm/incidents/:id OK (known ticket)" : path + " OK");
}
