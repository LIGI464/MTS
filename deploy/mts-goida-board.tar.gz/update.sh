#!/usr/bin/env bash
# Upgrade the existing MTS Compose service from the VPS root console.
set -Eeuo pipefail
umask 077

fail() { printf '%s\n' "$*" >&2; exit 1; }
sha=fa23cb1f71819ea9fb0d837a0b8e60b40f76df2d
origin=https://skinsloot.tech
bundle=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
project=${MTS_COMPOSE_PROJECT:-mts-cybergarden}
env_file=${MTS_VPS_ENV:-/srv/mts-cybergarden/dashboard.env}
compose_file=${MTS_COMPOSE_FILE:-/srv/mts-cybergarden/release/deploy/compose.yaml}
backup_root=/var/backups/mts-cybergarden
unset MTS_IMAGE_TAG

(cd -- "$bundle" && sha256sum --check source.sha256)
if [[ ${1:-} == --verify ]]; then
    tar -tzf "$bundle/source.tar.gz" >/dev/null
    exit 0
fi
[[ $(id -u) == 0 ]] || fail 'Run this script as root on the VPS.'
[[ -f "$env_file" && ! -L "$env_file" && -f "$compose_file" ]] || fail 'Existing Compose or env file was not found. Set MTS_VPS_ENV and MTS_COMPOSE_FILE to the paths used on this VPS.'
exec 9> /run/lock/mts-cybergarden-deploy.lock
flock -n 9 || fail 'Another MTS upgrade is in progress.'

compose=(docker compose --project-name "$project" --env-file "$env_file" -f "$compose_file")
running=$("${compose[@]}" ps --status running --quiet dashboard)
[[ -n "$running" && "$running" != *$'\n'* ]] || fail 'Expected exactly one running dashboard container in the existing Compose project.'
old_image=$(docker inspect --format '{{.Config.Image}}' "$running")
old_id=$(docker inspect --format '{{.Image}}' "$running")
target_image=mts-dashboard:$sha
configured_image=$("${compose[@]}" config --images dashboard)
[[ "$old_image" == "$configured_image" && "$old_image" == mts-dashboard:* ]] || fail 'Running image and Compose image differ. Inspect the current project first.'
[[ $(docker image inspect --format '{{.Id}}' "$old_image") == "$old_id" ]] || fail 'The running image no longer matches its tag.'
[[ $(MTS_IMAGE_TAG="$sha" "${compose[@]}" config --images dashboard) == "$target_image" ]] || fail 'The existing Compose file does not select the new tag through MTS_IMAGE_TAG.'
data_dir=$(docker inspect --format '{{range .Mounts}}{{if and (eq .Destination "/app/data/runtime") (eq .Type "bind")}}{{.Source}}{{end}}{{end}}' "$running")
[[ "$data_dir" == /* && "$data_dir" != / && -d "$data_dir" ]] || fail 'Expected the existing MTS data bind mount.'
for file in character_problems.json baseline.json dashboard.sqlite; do
    [[ -f "$data_dir/$file" ]] || fail "Required file missing in the current data directory: $file"
done

check_routes() {
    "${compose[@]}" exec -T dashboard node --input-type=module - "$1" < "$bundle/check-routes.mjs"
}
smoke() {
    "${compose[@]}" exec -T dashboard node deploy/smoke.mjs "$1"
}

if [[ "$old_image" == "$target_image" ]]; then
    smoke "$origin"
    check_routes "$origin"
    printf 'Already running %s at %s/admin/incidents\n' "$sha" "$origin"
    exit 0
fi

printf 'Current image: %s (%s)\n' "$old_image" "$old_id"
smoke http://127.0.0.1:8787
smoke "$origin"

stage=$(mktemp -d)
next_env=
backup=
rollback=0
finish() {
    rc=$?
    trap - EXIT INT TERM
    if ((rollback)); then
        printf 'Restoring previous image: %s\n' "$old_image" >&2
        if MTS_IMAGE_TAG="${old_image#mts-dashboard:}" "${compose[@]}" up -d --no-deps --no-build --pull never --wait dashboard &&
           smoke http://127.0.0.1:8787 && smoke "$origin"; then
            printf 'Rollback smoke passed: %s\n' "$old_image" >&2
        else
            printf 'Rollback smoke failed. Inspect Compose and backup: %s\n' "$backup" >&2
            rc=1
        fi
    fi
    [[ -z "$next_env" ]] || rm -f -- "$next_env"
    rm -rf -- "$stage"
    exit "$rc"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

tar -xzf "$bundle/source.tar.gz" -C "$stage"
new_compose=(docker compose --project-name "$project" --env-file "$env_file" -f "$stage/deploy/compose.yaml")
MTS_IMAGE_TAG="$sha" "${new_compose[@]}" build dashboard
[[ $(docker image inspect --format '{{index .Config.Labels "org.opencontainers.image.revision"}}' "$target_image") == "$sha" ]] ||
    fail 'Built image revision does not match the selected Git commit.'

install -d -m 0700 "$backup_root"
backup=$(mktemp -d "$backup_root/$(date -u +%Y%m%dT%H%M%SZ).XXXXXXXX")
cp -p -- "$env_file" "$backup/dashboard.env"
printf '%s\n%s\n' "$old_image" "$old_id" > "$backup/image.txt"
next_env=$(mktemp "$(dirname -- "$env_file")/.mts-env.XXXXXXXX")
cp -p -- "$backup/dashboard.env" "$next_env"
# Compose uses the last assignment. Keep all existing lines and verify the
# staged file resolves to the same configuration used for the trial start.
printf '\nMTS_IMAGE_TAG=%s\n' "$sha" >> "$next_env"
staged_compose=(docker compose --project-name "$project" --env-file "$next_env" -f "$compose_file")
[[ $("${staged_compose[@]}" config --images dashboard) == "$target_image" ]] || fail 'The prepared env file does not select the new image.'
trial_config_hash=$(MTS_IMAGE_TAG="$sha" "${compose[@]}" config --format json | sha256sum)
staged_config_hash=$("${staged_compose[@]}" config --format json | sha256sum)
[[ "$trial_config_hash" == "$staged_config_hash" ]] || fail 'The prepared env file changes other resolved Compose settings.'
cmp -s -- "$env_file" "$backup/dashboard.env" || fail 'Server settings changed during the deployment.'

rollback=1
"${compose[@]}" stop dashboard
tar -czf "$backup/data.tar.gz" -C "$data_dir" .
tar -tzf "$backup/data.tar.gz" >/dev/null
(cd -- "$backup" && sha256sum data.tar.gz > data.sha256)
printf 'Backup: %s\n' "$backup"
MTS_IMAGE_TAG="$sha" "${compose[@]}" up -d --no-deps --no-build --pull never --wait dashboard
new_container=$("${compose[@]}" ps --status running --quiet dashboard)
[[ $(docker inspect --format '{{.Config.Image}}' "$new_container") == "$target_image" ]] || fail 'Unexpected running image.'
[[ $(docker inspect --format '{{range .Mounts}}{{if eq .Destination "/app/data/runtime"}}{{.Source}}{{end}}{{end}}' "$new_container") == "$data_dir" ]] ||
    fail 'The new container did not mount the existing data directory.'
smoke http://127.0.0.1:8787
check_routes http://127.0.0.1:8787
smoke "$origin"
check_routes "$origin"

cmp -s -- "$env_file" "$backup/dashboard.env" || fail 'Server settings changed during the deployment.'
mv -T -- "$next_env" "$env_file"
rollback=0
printf 'DEPLOYED %s %s/admin/incidents\nROLLBACK_IMAGE %s\nBACKUP %s\n' "$sha" "$origin" "$old_image" "$backup"
